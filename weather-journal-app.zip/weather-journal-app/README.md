# Weather-Journal App Project

## Overview
I made this project using the rules of nodejs, making two files of js one for the clientside and the other for the serverside ,
and the other files for html and css and md files.

## server file
I downloaded my packages using the terminal and made an instance of my app then I make two routes one for get and the other for post data.

## client file
I made my constants then I made an event to perform an asynchronous function using then syntax to get data from that function and then updatingUI with the magic of asynchronous functions.

## html file
I used the same html codes after some editing.
## css file
I completely changed the css file using my special style.
